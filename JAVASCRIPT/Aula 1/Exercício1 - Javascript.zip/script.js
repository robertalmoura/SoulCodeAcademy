var boas_vindas = "Hello World Javascript!";
var nome = "Roberta";
var idade = 39;
var altura = 1.57;

document.write(boas_vindas, ". Eu sou a ", nome, " tenho ", idade, " anos de idade e ", altura, " de altura.")

alert("Fim da atividade.")















// Roberta Moura